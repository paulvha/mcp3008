/*
 *  readMcp3008.c:
 *  read value from ADC MCP3008
 *
 * Requires: wiringPi (http://wiringpi.com)
 * Copyright (c) 2015 http://shaunsbennett.com/piblog
 *
 * Adjusted with examples February 2016 : paulvh
 *
 *
 *      MCP3008     RASP
 * GND  9 + 14      GND
 * 3.3v 16 + 15     3.3V
 *                  pin GPIO
 * CS   10          24   8      cs0
 * Din  11          19   10     MOSI
 * Dout 12          21   9      MISO
 * CLK  13          23   11     clk
 *
 * march 2016 / paulvha
 *
 * - added support for BCM2835 library
 *      select with ./build bcm
 *      else ./build pi
 *
 * - tested with hs42led library
 *
 *  To use with hs42led, copy the files from both mcp3008 and hs42led
 *  in a single directory and start ./build_with bcm or ./build-with pi
 *
 ***********************************************************************
 */
#define _GNU_SOURCE

// better to use the option with ./build (see header)

//# define _hs42led     // enable hs42led
//# define _wiring      // enable wiringPi instead of BCM2835 library

/** WARNING  !! issue with wiringPi
 * if you tried to use bcm2835 library and then the wiringPi
 * it will not work. This is a kernel-driver issue
 * it needs a reboot first.
 */

#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <stdint.h>
#include <string.h>
#include <errno.h>

#ifdef _wiring
#include <wiringPi.h>
#include <wiringPiSPI.h>
#else
#include <bcm2835.h>
#endif


#ifdef _hs42led
#include "hs42led.h"
#endif

#define TRUE                (1==1)
#define FALSE               (!TRUE)
#define CHAN_CONFIG_SINGLE  8
#define CHAN_CONFIG_DIFF    0

// pinnumber for led
static int pin = 17;        // default GPIO 17
static int myFd ;

// channels to use
int analogChannel=0;
int spiChannel=0;
int channelConfig=CHAN_CONFIG_SINGLE;
int L_INP=1;
int P_INP=0;


char *usage = "Usage: mcp3008 all|analogChannel[1-8] [-ce1] [-d] [-v X.x] \n\
\t-ce1\t = spi analogChannel 1, default:  0\n\
\t-d\t = differential analogChannel input, default: single ended\n\
\t-v\t = reference voltage, default: 3.3v\n\
\t-l\t = GPIO for led, default: 17\n\n\
\t-bl A\t = blink on input analogchannel\n\
\t-lm35 A P = lm35 reading on A, potmeter on P\n\
\t-ldr A P\t = ldr reading on A, potmeter on P\n\
\t-all\t = read all analog channels.\n";

#ifdef _hs42led
/*
 * display degrees on the digits
 * string = string to display
 * len = length of the string
 */
void display_string( char buf[], int len)
{
    int lp=0, digit = 0;

    for(lp=0; lp < len; lp++)
    {
        // set dot on previous digit
        if (buf[lp] == '.') set_dot(digit-1,SET);

        // skip the + sign (can't display)
        else if (buf[lp] == '+')
            continue;

        else
            set_char(digit++ ,buf[lp]);

    }
    // display degrees
    set_char(3,'@');
}

#endif

#ifdef _wiring

void spiSetup (int spiChannel)
{
        printf("setting up SPI with wiringPi %d\n", spiChannel);
    if ((myFd = wiringPiSPISetup(spiChannel, 1000000)) < 0)
    {
        fprintf (stderr, "Can't open the SPI bus: %s\n", strerror (errno)) ;
        exit (EXIT_FAILURE) ;
    }
}
#endif

// for MCP3008 = 8 channels
int myAnalogRead(int spiChannel,int channelConfig,int analogChannel)
{
    if(analogChannel<0 || analogChannel>7)
        return -1;

    unsigned char buffer[3] = {1}; // start bit

    /* sending
     *
     * byte 0 00000001  start bit set
     * byte 1 xyyy----  x = single/diff yyy= analog address - = dont care
     * byte 2 --------  don't care, needed to reading value from mcp
     *
     * receiving
     * byte 1 -----0zz  z= value read (B9, B8)
     * byte 2 zzzzzzzz  z= value read (B7, B6, B5, B4, B3, B2, B1, B0)
     *
     */
    buffer[1] = (channelConfig+analogChannel) << 4;

#ifdef _wiring
    wiringPiSPIDataRW(spiChannel, buffer, 3);
#else
    bcm2835_spi_chipSelect(spiChannel);
    bcm2835_spi_transfern(buffer, 3);
#endif

    return ( (buffer[1] & 3 ) << 8 ) + buffer[2]; // get last 10 bits
}

void mcp_init(int spiCh)
{
#ifdef _hs42led
    printf("using HS42led  & ");

    /* initialise and set control-c on.*/
    // MUST ALWAYS BE DONE FIRST !!
    do_init(CTRLC);

    // set for higher refresh rate on the leds
    //set_refresh(5);

# ifdef _wiring
    printf("wiringPi library\n");

    if (gpio_set == 0){     // should have been done in do_init
        wiringPiSetupGpio();
        gpio_set=1;
    }

    spiSetup(spiCh);
    pinMode (pin, OUTPUT);

# else
    printf("BCM2835 library\n");
    bcm2835_init();
    bcm2835_spi_begin();
    bcm2835_spi_setClockDivider(BCM2835_SPI_CLOCK_DIVIDER_256); //976Khz
    bcm2835_gpio_fsel(pin, BCM2835_GPIO_FSEL_OUTP);
    bcm2835_gpio_write(pin,LOW);
# endif  // _wiring
#else       // not _hs42led
# ifdef _wiring
    printf("using wiringPi library\n");

    wiringPiSetupGpio();
    spiSetup(spiCh);
    pinMode (pin, OUTPUT);

# else
    printf("using BCM2835 library\n");
    bcm2835_init();
    bcm2835_spi_begin();
    bcm2835_spi_setClockDivider(BCM2835_SPI_CLOCK_DIVIDER_256); //976Khz
    bcm2835_gpio_fsel(pin, BCM2835_GPIO_FSEL_OUTP);
    bcm2835_gpio_write(pin,LOW);
# endif  //_wiring
#endif  // hs_42led
}

// set output led
void set_pin(int pin, int val)
{
#ifdef _wiring
    digitalWrite(pin, val);
#else
    bcm2835_gpio_write(pin,val);
#endif
}

void ldr()
{
    /* LDR will trigger the led on, depending on the daylight.
     *
     * The potmeter will determine the cut of moment for daylight
     *
     * LDR setup :
     *       ___________       ____________
     * GND -[____10K____]--+--[____LDR_____] -- +3.3V
     *                     |
     *                     analog  a, physical pin a+1
     *
     * potmeter (10K) :
     *       ____________
     * GND -[           ] +3.3V
     *      [___________]
     *             ^
     *             |
     *             analog  p, physical pin p+1
     *
     * Led
     *      ________       <|
     * GND-[___470__]---|<  |---- pin (GPIO 17)
     *                     <|
     *
     */

    int prev=0;             // remember current state led
    int i,j;


    while(TRUE) {
           // read LDR
        j = myAnalogRead(spiChannel,channelConfig,L_INP);

           // get potmeter value
        i = myAnalogRead(spiChannel,channelConfig,P_INP);

        i = i * 900 / 1023;     // LDR provides range ~400 - ~900

        //debug
        //printf("LDR value %d, potmeter value: %d\n",j,i);
        if (j < i) {
            if (prev == 0) {
                prev = 1;
                set_pin(pin, 1) ;
#ifdef _hs42led
                set_char(1,'1');
#endif
                printf("**** To dark : switched lights on ****\n");
            }
        }
        else {
            if (prev == 1) {
                prev = 0;
                set_pin(pin, 0);
#ifdef _hs42led
                set_char(1,'0');
#endif
                printf("**** Daylight:  switched lights off ****\n");
            }
        }
#ifdef _hs42led
        psleep(1 * 1000 / 5 );
#else
        sleep(1);
#endif

    }
}

void lm35()
{
    /* read temperature from LM35
     * potmeter acts as control to switch on heating (=led)
     *
     * Front view :
     *   --------
     *   [ lm35 ]
     *   [      ]
     *   [______]
     *    /  |  \
     *   /   |   \
     * 3.3V  |   GND
     *      analog  a, physical pin a+1
     *
     * potmeter (10K) :
     *      -------------
     * GND -[           ] +3.3V
     *      [___________]
     *             ^
     *             |
     *             analog  p, physical pin p+1
     *
     *  Led
     *      ________       <|
     * GND [___470__]---|<  |---- pin (GPIO 17)
     *                     <|
     *
     *

     *
     */
    int i,j;
    float voltage = 3.3;    // reference voltage
    float k,r;              // calculate floats
    int prev=0;             // remember previous status
    char text[10];

     while(TRUE){
              // temperature from LM35
            j = myAnalogRead(spiChannel,channelConfig,L_INP);

              // get potmeter value
            i = myAnalogRead(spiChannel,channelConfig,P_INP);

            r = (j * voltage) / 1024;       // calculate to volts

            k = r / (10.0 / 1000);          // 10mV per 1 degree C

            // correction 1 degree (reading is not perfect)
            k = k - 1;

            printf ("temperature C: %4.1f F: %4.1f\n",k,(k*9)/5+32);
#ifdef _hs42led
            sprintf(text,"%4.1f\0",k );
            display_string(text, sizeof(text));
#endif
            // 30 => ~9.6 , 80 => ~ 25.7, 100 => ~32.2
            // normalize/adjust around midpoint
            i = i * 80 / 1023;

            //debug
            //printf ("Current : %d, switch at %d\t",j,i);

            if (j < i) {
                if (prev == 0) {
                    prev = 1;
                    set_pin (pin, 1);
#ifdef _hs42led
                    set_dot(3,1);
#endif
                    printf("**** Heating on. ****\n");
                }
            }
            else {
                if (prev == 1) {
                    prev = 0;
                    set_pin (pin, 0) ;
#ifdef _hs42led
                    set_dot(3,0);
#endif
                    printf("**** Heating off. ****\n");
                }
            }
#ifdef _hs42led
            psleep(2 *1000/5 );  //psleep[1 = 5ms]

#else
            sleep(2);
#endif
        }
}

void blinky(int blink)
{
    /*
     * Show the value of potmeter or blink LED
     * potmeter (10K) :
     *
     *      -------------
     * GND -[           ] +3.3V
     *      [___________]
     *             ^
     *             |
     *             analog  p, physical pin p+1
     * Led
     *      ________       <|
     * GND [___470__]---|<  |---- pin (GPIO 17)
     *                     <|
     *
     *
     * with -b option :
     *      blink
     *      The potmeter will determine the blink speed.
     *
     *
     * if potmeter zero => stop
     */
    int j;
    float k, voltage = 3.3;    // reference voltage
    int prev=0;                // remember previous status

    if (blink == 1) {

        while (TRUE){           // loop until analog value = 0 / break

            // get potmeter value
            j = myAnalogRead(spiChannel,channelConfig,P_INP);

            if (j == 0){
                printf("value zero: done\n");
#ifdef _hs42led
                set_char(1,'0');
#endif
                break;
            }

            if (prev == 0) {    //switch
                prev = 1;
                set_pin (pin, 1) ;
#ifdef _hs42led
                set_char(1,'1');
#endif
                printf("On \t");
            }
            else {
                prev = 0;
                set_pin (pin, 0);
#ifdef _hs42led
                set_char(1,'0');
#endif
                printf("Off \t");
            }

            printf("waiting %d second(s)\n",j/100);
#ifdef _hs42led
            psleep((j/100)*1000/5);
#else
            sleep(j/100);
#endif
        }
    }
    else {

        // get potmeter value
        j = myAnalogRead(spiChannel,channelConfig,P_INP);

        // calculate voltage (3.3 is default reference voltage)
        k = (voltage * j)/1023;

        printf("MCP3008(CE%d,%s): analogChannel %d = %d or %2.2fV\n",spiChannel,(channelConfig==CHAN_CONFIG_SINGLE)
                   ?"single-ended":"differential",0,j,k);
   }
}


int main (int argc, char *argv [])
{
    int ld=0,lm=0,all=0;
    int i,j;
    float voltage = 3.3;    // reference voltage
    float k;                // calculate floats
    int blink=0;
    int prev=0;             // remember previous status

    if (argc < 2)
    {
        fprintf (stderr, "%s\n", usage) ;
        return 1 ;
    }

    for(i=1; i<argc; i++)
    {
        printf("i %s\n",argv[i]);
        if (strcasecmp (argv [i], "-ce1") == 0)
            spiChannel=1;

        if (strcasecmp (argv [i], "-d") == 0 || strcasecmp (argv [i], "-diff") == 0)
            channelConfig=CHAN_CONFIG_DIFF;

        if (strcasecmp (argv [i], "-l") == 0){
            i++;

            if (i == argc){

                printf ("missing GPIO\n%s\n",  usage) ;
                return 1;
            }
            // get input analog for potmeter
            if (sscanf (argv[i], "%d", &pin) != 1)
            {
                printf ("incorrect analog channel\n%s\n",  usage) ;
                return 1 ;
            }


        }
        if (strcasecmp (argv [i], "-bl") == 0){
            blink=1;    // set for blink on single line

            i++;

            if (i == argc){
                printf ("missing analog channel\n%s\n",  usage) ;
                return 1;
            }
            // get input analog for potmeter
            if (sscanf (argv[i], "%d", &P_INP) != 1)
            {
                printf ("incorrect analog channel\n%s\n",  usage) ;
                return 1 ;
            }

        }

        else if(strcasecmp (argv [i], "-ldr") == 0){
            ld=1;

            i++;

            if (i == argc){
                printf ("missing analog channel\n%s\n",  usage) ;
                return 1;
            }
            // get input analog for ldr
            if (sscanf (argv[i], "%d", &L_INP) != 1)
            {
                printf ("incorrect analog channel\n%s\n",  usage) ;
                return 1 ;
            }


            i++;

            if (i == argc){
                printf ("missing analog channel\n%s\n",  usage) ;
                return 1;
            }
            // get input analog for potmeter
            if (sscanf (argv[i], "%d", &P_INP) != 1)
            {
                printf ("incorrect analog channel\n%s\n",  usage) ;
                return 1 ;
            }

        }

        else if(strcasecmp (argv [i], "-lm35") == 0){
            lm=1;

            i++;

            if (i == argc){
                printf ("missing analog channel\n%s\n",  usage) ;
                return 1;
            }
            // get input analog for LM35
            if (sscanf (argv[i], "%d", &L_INP) != 1)
            {
                printf ("incorrect analog channel\n%s\n",  usage) ;
                return 1 ;
            }


            i++;

            if (i == argc){
                printf ("missing analog channel\n%s\n",  usage) ;
                return 1;
            }
            // get input analog for potmeter
            if (sscanf (argv[i], "%d", &P_INP) != 1)
            {
                printf ("%s\n",  usage) ;
                return 1 ;
            }


        }

        else if(strcasecmp (argv [i], "-all") == 0){
            all=1;
        }

        if (strcasecmp (argv [i], "-v") == 0){
                        // get different reference voltage
            i++;

            if (i == argc){
                printf ("%s\n",  usage) ;
                return 1 ;
            }

            if (sscanf (argv[i], "%f", &voltage) != 1)
            {
                printf ("%s\n",  usage) ;
                return 1 ;
            }
        }
    }
    // intitialise
    mcp_init(spiChannel);
    printf("blink %d, ld %d, lm %d\n",blink, ld, lm);
    if (lm) lm35();

    else if (blink) blinky(blink);

    else if (ld)   ldr();

    else if (all) // show all
    {
        for(i=0; i<8; i++)
        {
            j = myAnalogRead(spiChannel,channelConfig,i);

            // calculate voltage (3.3 is default reference voltage)
            k = (voltage * j)/1023;

            printf("MCP3008(CE%d,%s): analogChannel %d (pin = %d) = %d or %2.2fV\n",spiChannel,(channelConfig==CHAN_CONFIG_SINGLE)
                   ?"single-ended":"differential",i,i+1,j,k);
        }
    }
    else
        printf ("No display option selected\n%s\n",  usage) ;


#ifdef _wiring
    close (myFd);
#else
    bcm2835_spi_end();
#endif
    return 0;
}
